class Constants {
  static final baseUrl = "http://192.168.120.189/restful_api_ci4/public";
  static late String access_token = "";
}
